// Wokwi Custom Chip - INMP441 Simple Simulator
// SPDX-License-Identifier: MIT

#include "wokwi-api.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct {
  pin_t sd;     // DOUT pin
  float phase;  // Pha sóng sin
  float freq;   // Tần số sóng (Hz)
  float sample_rate; // Tần số lấy mẫu (Hz)
  uint32_t tick_count;
} chip_state_t;

static chip_state_t chip;  // Biến toàn cục thay cho user_data

void chip_init() {
  chip.sd = pin_init("SD", OUTPUT);
  chip.freq = 1000.0;          // 1kHz sóng sin
  chip.sample_rate = 48000.0;  // 48kHz tần số mẫu
  chip.phase = 0.0;
  chip.tick_count = 0;

  printf("INMP441 simple simulator started (%.0f Hz sine)\n", chip.freq);
}

void chip_tick() {
  // Mỗi tick mô phỏng 1 bước nhỏ thời gian
  chip.tick_count++;
  double dt = 1.0 / chip.sample_rate;
  chip.phase += 2 * M_PI * chip.freq * dt;

  // Tạo mẫu sóng sin từ -1.0 đến 1.0
  float sample = sin(chip.phase);

  // Xuất ra chân SD: HIGH khi dương, LOW khi âm
  pin_write(chip.sd, sample > 0 ? HIGH : LOW);
}
